using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;

namespace TIA_Coustomization
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var filePath = "C:\\Users\\AshwiniT\\Documents\\TIA\\S1_RFID_VC.xml";
            string Dest_pl_str = PalletType.Text;
            string Dest_pn_str = PalletNumber.Text;
            string Dest_sc1_str = ShipCode1.Text;
            string Dest_sc2_str = ShipCode2.Text;
            string Dest_sc3_str = ShipCode3.Text;
            string Dest_sc4_str = ShipCode4.Text;
            string Dest_mj1_str = RecpMajorVersNo.Text;
            string Dest_mj2_str = RecpMinorVersNo.Text;
            string Dest_Task_d_str = TaskData.Text;
            string Dest_Task_d_counter_str = TaskData_Counter.Text;
            string Dest_Task_d_l_str = TaskDataLowerNibble.Text;
            string Dest_op_sat_str = OpStatus.Text;

            // Convert string values to the desired types
            byte Dest_pl = byte.Parse(Dest_pl_str);
            int Dest_pn = int.Parse(Dest_pn_str);
            char Dest_sc1 = Dest_sc1_str[0]; // Assuming you want to take the first character
            char Dest_sc2 = Dest_sc2_str[0];
            char Dest_sc3 = Dest_sc3_str[0];
            char Dest_sc4 = Dest_sc4_str[0];
            byte Dest_mj1 = byte.Parse(Dest_mj1_str);
            byte Dest_mj2 = byte.Parse(Dest_mj2_str);
            sbyte? Dest_Task_d = !string.IsNullOrEmpty(Dest_Task_d_str) ? sbyte.Parse(Dest_Task_d_str) : (sbyte?)-1;
            int Dest_Task_d_counter = int.Parse(Dest_Task_d_counter_str);
            sbyte? Dest_Task_d_l = !string.IsNullOrEmpty(Dest_Task_d_l_str) ? sbyte.Parse(Dest_Task_d_l_str) : (sbyte?)-1;
            int Dest_op_sat = int.Parse(Dest_op_sat_str);



            var src_pl = pltype_label.Text + "_Place_Holder";
            var src_pn = pnum.Text + "_Place_Holder";
            var src_sc1 = shipc1.Text + "_Place_Holder";
            var src_sc2 = shipc2.Text + "_Place_Holder";
            var src_sc3 = shipc3.Text + "_Place_Holder";
            var src_sc4 = shipc4.Text + "_Place_Holder";
            var src_mj1 = maj1.Text + "_Place_Holder";
            var src_mj2 = maj2.Text + "_Place_Holder";
            var src_Task_d = Tasd.Text + "_Place_Holder";
            var src_Task_d_counter = Tasd.Text + "_Counter";
            var src_Task_d_l = taskdl.Text + "_Place_Holder";
            var src_op_sat = opstat.Text + "_Counter";



            XDocument doc = XDocument.Load(filePath);

            // Find the element with the name "Number" and update its value to "8"
            XElement numberElement = doc.Descendants("Number").FirstOrDefault();
            if (numberElement != null)
            {
                numberElement.SetValue(FC_Num.Text);
            }
            else
            {
                MessageBox.Show("Element <Number> not found.");
            }

            // Save the modified XML document
            doc.Save(filePath);

            ReplaceWord(src_pl, Dest_pl, filePath);
            ReplaceWord(src_pn, Dest_pn, filePath);
            ReplaceWord(src_sc1, Dest_sc1, filePath);
            ReplaceWord(src_sc2, Dest_sc2, filePath);
            ReplaceWord(src_sc3, Dest_sc3, filePath);
            ReplaceWord(src_sc4, Dest_sc4, filePath);
            ReplaceWord(src_mj1, Dest_mj1, filePath);
            ReplaceWord(src_mj2, Dest_mj2, filePath);
            ReplaceWord(src_op_sat, Dest_op_sat, filePath);

            if (((sbyte)Dest_Task_d) == -1)
            {
                CommentDown(filePath, "TASK STAUS HIGHER AND LOWER NIBBLE");


            }
            else
            {
                ReplaceWord(src_Task_d, Dest_Task_d, filePath);
                ReplaceWord(src_Task_d_counter, Dest_Task_d_counter, filePath);
            }
            if (((sbyte)Dest_Task_d_l) == -1)
            {
                CommentDown(filePath, "TASK STAUS LOWER ONLY NIBBLE NIBBLE");
            }
            else
            {
                ReplaceWord(src_Task_d_l, Dest_Task_d_l, filePath);
            }

        }
        private void ReplaceWord(string sourcevalue, object targetvalue, string filePath)
        {
            try
            {
                // Load the XML document using XDocument
                XDocument doc = XDocument.Load(filePath);

                // Define the namespace
                XNamespace ns = "http://www.siemens.com/automation/Openness/SW/NetworkSource/FlgNet/v4";

                // Get all Access elements under the defined namespace
                var accessNodes = doc.Descendants(ns + "Access").ToList();
                foreach (var accessNode in accessNodes)
                {
                    var constantValueElement = accessNode.Descendants(ns + "ConstantValue").FirstOrDefault();

                    if (constantValueElement != null && constantValueElement.Value == sourcevalue)
                    {

                        //constantValueElement.Value = targetvalue;
                        if (targetvalue.GetType() == typeof(char))
                        {
                            char charValue = (char)targetvalue;
                            constantValueElement.Value = "'" + charValue.ToString() + "'";
                        }
                        else
                        {
                            var targetvalue_str = Convert.ToString(targetvalue);
                            constantValueElement.Value = targetvalue_str;

                        }
                    }

                }

                doc.Save(filePath);
                MessageBox.Show("Commented successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }


        private void CommentDown(string filePath, string Operation_name)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(filePath); // Provide the path to your XML file


                XmlNodeList compileUnits = doc.SelectNodes("//SW.Blocks.CompileUnit");

                foreach (XmlNode compileUnit in compileUnits)
                {
                    XmlNode networkSourceNode = compileUnit.SelectSingleNode("AttributeList/NetworkSource");
                    // Find the title tet node
                    XmlNode titleNode = compileUnit.SelectSingleNode("ObjectList/MultilingualText[@CompositionName='Title']/ObjectList/MultilingualTextItem/AttributeList/Text");
                    if (titleNode != null && titleNode.InnerText.Trim() == Operation_name)
                    {
                        // Find the NetworkSource node

                        if (networkSourceNode != null)
                        {
                            XmlElement netNode = doc.CreateElement("NetworkSource");

                            // Insert the empty <net> node before the <NetworkSource> node
                            networkSourceNode.ParentNode.InsertBefore(netNode, networkSourceNode);
                            // Comment out the NetworkSource node
                            XmlComment comment = doc.CreateComment(networkSourceNode.OuterXml);
                            networkSourceNode.ParentNode.ReplaceChild(comment, networkSourceNode);
                        }
                    }
                }
                // Save the modified document
                doc.Save(filePath); // Provide the path where you want to save the modified XML
                MessageBox.Show("NetworkSource tag commented out successfully.");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private string RemoveNamespaceDeclaration(string xml)
        {
            // Remove the xmlns attribute along with its value
            return Regex.Replace(xml, @"xmlns="".*?""", "");
        }


    }
}