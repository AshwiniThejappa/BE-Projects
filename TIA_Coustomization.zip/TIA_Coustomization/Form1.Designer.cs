﻿namespace TIA_Coustomization
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            PalletType = new TextBox();
            PalletNumber = new TextBox();
            ShipCode1 = new TextBox();
            ShipCode2 = new TextBox();
            ShipCode3 = new TextBox();
            ShipCode4 = new TextBox();
            pltype_label = new Label();
            pnum = new Label();
            shipc1 = new Label();
            shipc2 = new Label();
            shipc3 = new Label();
            shipc4 = new Label();
            RecpMajorVersNo = new TextBox();
            TaskDataLowerNibble = new TextBox();
            RecpMinorVersNo = new TextBox();
            TaskData = new TextBox();
            OpStatus = new TextBox();
            maj1 = new Label();
            opstat = new Label();
            Tasd = new Label();
            taskdl = new Label();
            maj2 = new Label();
            TaskData_Counter = new TextBox();
            label1 = new Label();
            FC_Num = new TextBox();
            label2 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(272, 360);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 0;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // PalletType
            // 
            PalletType.Location = new Point(575, 54);
            PalletType.Name = "PalletType";
            PalletType.Size = new Size(100, 23);
            PalletType.TabIndex = 1;
            // 
            // PalletNumber
            // 
            PalletNumber.Location = new Point(575, 99);
            PalletNumber.Name = "PalletNumber";
            PalletNumber.Size = new Size(100, 23);
            PalletNumber.TabIndex = 2;
            // 
            // ShipCode1
            // 
            ShipCode1.Location = new Point(575, 168);
            ShipCode1.Name = "ShipCode1";
            ShipCode1.Size = new Size(100, 23);
            ShipCode1.TabIndex = 3;
            // 
            // ShipCode2
            // 
            ShipCode2.Location = new Point(575, 236);
            ShipCode2.Name = "ShipCode2";
            ShipCode2.Size = new Size(100, 23);
            ShipCode2.TabIndex = 4;
            // 
            // ShipCode3
            // 
            ShipCode3.Location = new Point(575, 305);
            ShipCode3.Name = "ShipCode3";
            ShipCode3.Size = new Size(100, 23);
            ShipCode3.TabIndex = 5;
            // 
            // ShipCode4
            // 
            ShipCode4.Location = new Point(575, 360);
            ShipCode4.Name = "ShipCode4";
            ShipCode4.Size = new Size(100, 23);
            ShipCode4.TabIndex = 6;
            // 
            // pltype_label
            // 
            pltype_label.AutoSize = true;
            pltype_label.BackColor = SystemColors.ButtonFace;
            pltype_label.Location = new Point(476, 59);
            pltype_label.Name = "pltype_label";
            pltype_label.Size = new Size(60, 15);
            pltype_label.TabIndex = 7;
            pltype_label.Text = "PalletType";
            // 
            // pnum
            // 
            pnum.AutoSize = true;
            pnum.Location = new Point(456, 102);
            pnum.Name = "pnum";
            pnum.Size = new Size(80, 15);
            pnum.TabIndex = 8;
            pnum.Text = "PalletNumber";
            // 
            // shipc1
            // 
            shipc1.AutoSize = true;
            shipc1.Location = new Point(472, 171);
            shipc1.Name = "shipc1";
            shipc1.Size = new Size(64, 15);
            shipc1.TabIndex = 9;
            shipc1.Text = "ShipCode1";
            shipc1.Click += label3_Click;
            // 
            // shipc2
            // 
            shipc2.AutoSize = true;
            shipc2.Location = new Point(472, 239);
            shipc2.Name = "shipc2";
            shipc2.Size = new Size(64, 15);
            shipc2.TabIndex = 10;
            shipc2.Text = "ShipCode2";
            // 
            // shipc3
            // 
            shipc3.AutoSize = true;
            shipc3.Location = new Point(476, 308);
            shipc3.Name = "shipc3";
            shipc3.Size = new Size(64, 15);
            shipc3.TabIndex = 11;
            shipc3.Text = "ShipCode3";
            // 
            // shipc4
            // 
            shipc4.AutoSize = true;
            shipc4.Location = new Point(472, 363);
            shipc4.Name = "shipc4";
            shipc4.Size = new Size(64, 15);
            shipc4.TabIndex = 12;
            shipc4.Text = "ShipCode4";
            // 
            // RecpMajorVersNo
            // 
            RecpMajorVersNo.Location = new Point(180, 54);
            RecpMajorVersNo.Name = "RecpMajorVersNo";
            RecpMajorVersNo.Size = new Size(100, 23);
            RecpMajorVersNo.TabIndex = 14;
            // 
            // TaskDataLowerNibble
            // 
            TaskDataLowerNibble.Location = new Point(180, 256);
            TaskDataLowerNibble.Name = "TaskDataLowerNibble";
            TaskDataLowerNibble.Size = new Size(100, 23);
            TaskDataLowerNibble.TabIndex = 15;
            // 
            // RecpMinorVersNo
            // 
            RecpMinorVersNo.Location = new Point(180, 102);
            RecpMinorVersNo.Name = "RecpMinorVersNo";
            RecpMinorVersNo.Size = new Size(100, 23);
            RecpMinorVersNo.TabIndex = 16;
            // 
            // TaskData
            // 
            TaskData.Location = new Point(180, 199);
            TaskData.Name = "TaskData";
            TaskData.Size = new Size(100, 23);
            TaskData.TabIndex = 17;
            TaskData.Text = "-1";
            // 
            // OpStatus
            // 
            OpStatus.Location = new Point(180, 149);
            OpStatus.Name = "OpStatus";
            OpStatus.Size = new Size(100, 23);
            OpStatus.TabIndex = 18;
            // 
            // maj1
            // 
            maj1.AutoSize = true;
            maj1.Location = new Point(55, 59);
            maj1.Name = "maj1";
            maj1.Size = new Size(101, 15);
            maj1.TabIndex = 19;
            maj1.Text = "RecpMajorVersNo";
            maj1.Click += label7_Click;
            // 
            // opstat
            // 
            opstat.AutoSize = true;
            opstat.Location = new Point(90, 157);
            opstat.Name = "opstat";
            opstat.Size = new Size(55, 15);
            opstat.TabIndex = 20;
            opstat.Text = "OpStatus";
            // 
            // Tasd
            // 
            Tasd.AutoSize = true;
            Tasd.Location = new Point(90, 207);
            Tasd.Name = "Tasd";
            Tasd.Size = new Size(53, 15);
            Tasd.TabIndex = 21;
            Tasd.Text = "TaskData";
            // 
            // taskdl
            // 
            taskdl.AutoSize = true;
            taskdl.Location = new Point(36, 259);
            taskdl.Name = "taskdl";
            taskdl.Size = new Size(120, 15);
            taskdl.TabIndex = 22;
            taskdl.Text = "TaskDataLowerNibble";
            // 
            // maj2
            // 
            maj2.AutoSize = true;
            maj2.Location = new Point(54, 110);
            maj2.Name = "maj2";
            maj2.Size = new Size(102, 15);
            maj2.TabIndex = 23;
            maj2.Text = "RecpMinorVersNo";
            // 
            // TaskData_Counter
            // 
            TaskData_Counter.Location = new Point(352, 199);
            TaskData_Counter.Name = "TaskData_Counter";
            TaskData_Counter.Size = new Size(100, 23);
            TaskData_Counter.TabIndex = 24;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(286, 202);
            label1.Name = "label1";
            label1.Size = new Size(50, 15);
            label1.TabIndex = 25;
            label1.Text = "Counter";
            // 
            // FC_Num
            // 
            FC_Num.Location = new Point(180, 308);
            FC_Num.Name = "FC_Num";
            FC_Num.Size = new Size(100, 23);
            FC_Num.TabIndex = 26;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(77, 316);
            label2.Name = "label2";
            label2.Size = new Size(68, 15);
            label2.TabIndex = 27;
            label2.Text = "FC Number";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(FC_Num);
            Controls.Add(label1);
            Controls.Add(TaskData_Counter);
            Controls.Add(maj2);
            Controls.Add(taskdl);
            Controls.Add(Tasd);
            Controls.Add(opstat);
            Controls.Add(maj1);
            Controls.Add(OpStatus);
            Controls.Add(TaskData);
            Controls.Add(RecpMinorVersNo);
            Controls.Add(TaskDataLowerNibble);
            Controls.Add(RecpMajorVersNo);
            Controls.Add(shipc4);
            Controls.Add(shipc3);
            Controls.Add(shipc2);
            Controls.Add(shipc1);
            Controls.Add(pnum);
            Controls.Add(pltype_label);
            Controls.Add(ShipCode4);
            Controls.Add(ShipCode3);
            Controls.Add(ShipCode2);
            Controls.Add(ShipCode1);
            Controls.Add(PalletNumber);
            Controls.Add(PalletType);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private TextBox PalletType;
        private TextBox PalletNumber;
        private TextBox ShipCode1;
        private TextBox ShipCode2;
        private TextBox ShipCode3;
        private TextBox ShipCode4;
        private Label pltype_label;
        private Label pnum;
        private Label shipc1;
        private Label shipc2;
        private Label shipc3;
        private Label shipc4;
        private TextBox RecpMajorVersNo;
        private TextBox TaskDataLowerNibble;
        private TextBox RecpMinorVersNo;
        private TextBox TaskData;
        private TextBox OpStatus;
        private Label maj1;
        private Label opstat;
        private Label Tasd;
        private Label taskdl;
        private Label maj2;
        private TextBox TaskData_Counter;
        private Label label1;
        private TextBox FC_Num;
        private Label label2;
    }
}